<?php
session_start();
if (!isset($_SESSION["user"])) {
   header("Location: login.php");
}
?>
 <!-- <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon"> -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="css/mdb.min.css">
  <style>
  .card
  {
	  
	  margin: 50px;
	  border-radius:15px;
    height:600px;
    margin-left:100 px;
    margin-right:70px;
  }
  img
  {
	  height:180px;
  }
  span
  {
	  font-weight:bolder;
	  font-size: large;
  }
  #visitsite
  {
	  text-decoration:none;
	  color:white;
  }
  .card-text
  {
	  font-weight:bolder;
	  font-size: large;
  }
</style>  
  <!--Navbar-->
<nav class="navbar navbar-expand-lg navbar-dark btn-dark">

  <!-- Navbar brand -->
  <a class="navbar-brand" href="#">PriceComparison</a>

  <!-- Collapse button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
    aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Collapsible content -->
  <div class="collapse navbar-collapse" id="basicExampleNav">

    <!-- Links -->
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home
          <span class="sr-only">(current)</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#footer">About-Us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.html">Contact-Us</a>
      </li>

      <!-- Dropdown -->
      <!-- <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown"
          aria-haspopup="true" aria-expanded="false">Dropdown</a>
        <div class="dropdown-menu dropdown-dark" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="https://www.amazon.com">Amazon</a>
          <a class="dropdown-item" href="https://www.flipkart.com">Flipkart</a>
        </div>
      </li> -->

      <!-- <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li> -->

    </ul>
    <!-- Links -->

    <form class="form-inline">
      <div class="md-form my-0">
      <button type="button" class="btn btn-dark"><a class="nav-link" href="logout.php">Logout</a></button>
      </div>
    </form>
  </div>
  <!-- Collapsible content -->

</nav>
<!--/.Navbar-->
<br><br>
<form class="form-inline d-flex justify-content-center md-form form-sm mt-0" action="index.php" method="POST">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search" name="searchtext" value=""
    aria-label="Search"><br><br>
  <input class="btn btn-dark btn-rounded " type="submit" value="Search">
</form>

<!--Section: Group of personal cards-->
<section class="pt-5 mt-3 pb-3">

  <!--Grid row-->
  <div class="row">

    <!--Grid column-->
    <div class="col-md-12">

      <!--Card group-->
      <div class="card-group">

        <!--Card-->
        <div class="card card-personal mb-6">

          <!--Card image-->
          <div class="view">
            <img class="card-img-top" src="flp.jpg" alt="Card image cap">
            <a href="#!">
              <div class="mask rgba-white-slight"></div>
            </a>
          </div>
          <!--Card image-->

          <!--Card content-->
          <div class="card-body">
            <!--Title-->
            <a>
              <h4 class="card-title">flipkart.com</h4>
            </a>
            <a class="card-meta">Search Results</a>

            <!--Text-->
            <p class="card-text">
			 <?php
require 'simple_html_dom.php';


$searchtext="";


if ($_SERVER["REQUEST_METHOD"] == "POST"){
$searchtext = $_POST["searchtext"];

}
$searchtext = str_replace(' ', '%20', $searchtext);
$flp_str1="https://www.flipkart.com/search?q=";
$flp_str2="&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off&as-pos=1&as-type=HISTORY";
$flp_query=$flp_str1.$searchtext.$flp_str2;

$html = file_get_html($flp_query);

// echo $html->find('a[class="s1Q9rs"]',0)->plaintext;
// echo "<span class='float-right'>";
// echo $html->find('div[class="_30jeq3"]',0)->plaintext;
// echo "</span><br><br>";



// echo $html->find('a[class="s1Q9rs"]',1)->plaintext;
// echo "<span class='float-right'>";
// echo $html->find('div[class="_30jeq3"]',1)->plaintext;
// echo "</span><br><br>";



// echo $html->find('a[class="s1Q9rs"]',2)->plaintext;
// echo "<span class='float-right'>";
// echo $html->find('div[class="_30jeq3"]',2)->plaintext;
// echo "</span><br><br>";

//1
if(isset($html->find('a[class="s1Q9rs"]',0)->plaintext)){

  // $product1 = $html->find('span[class="s1Q9rs"]',0)->plaintext;
  // $link1 = $flp_str1.$product1.$flp_str2;
  // echo "<a href='$link1' target='_blank'>$product1</a>"; 

  echo $html->find('a[class="s1Q9rs"]',0)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('div[class="_30jeq3"]',0)->plaintext;
  echo"</span><br><br>";

      
  echo $html->find('a[class="s1Q9rs"]',1)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('div[class="_30jeq3"]',1)->plaintext;
  echo"</span><br><br>";


  echo $html->find('a[class="s1Q9rs"]',2)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('div[class="_30jeq3"]',2)->plaintext;
  echo"</span><br><br>";
}


//2

if(isset($html->find('div[class="_4rR01T"]',0)->plaintext)){

  echo $html->find('div[class="_4rR01T"]',0)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('div[class="_30jeq3 _1_WHN1"]',0)->plaintext;
  echo "</span><br><br>";


  echo $html->find('div[class="_4rR01T"]',1)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('div[class="_30jeq3 _1_WHN1"]',1)->plaintext;
  echo "</span><br><br>";


  echo $html->find('div[class="_4rR01T"]',2)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('div[class="_30jeq3 _1_WHN1"]',2)->plaintext;
  echo "</span><br><br>";
}


?>
			
			
			
			
			</p>
            <hr>
            <button type="button" class="btn btn-primary"><a href="<?php echo $flp_query;?>" id="visitsite" target='_blank'>Visit Flipkart</a></button>
          </div>
          <!--Card content-->

        </div>
        <!--Card-->

        <!--Card-->
        <div class="card card-personal mb-6">

          <!--Card image-->
          <div class="view">
            <img class="card-img-top" src="amz.jpg" alt="Card image cap">
            <a href="#!">
              <div class="mask rgba-white-slight"></div>
            </a>
          </div>
          <!--Card image-->

          <!--Card content-->
          <div class="card-body">
            <!--Title-->
            <a>
              <h4 class="card-title">amazon.com</h4>
            </a>
            <a class="card-meta">Search Results</a>

            <!--Text-->
            <p class="card-text">
			<?php
      


$amz_str1="https://www.amazon.in/s?k=";
$amz_str2="&ref=nb_sb_noss_2";

$amz_query=$amz_str1.$searchtext.$amz_str2;



$html = file_get_html($amz_query);

// echo $html->find('span[class="a-size-medium a-color-base a-text-normal"]',0)->plaintext;
// echo "<span class='float-right'>";
// echo $html->find('span[class="a-price-symbol"]',0)->plaintext;
// echo $html->find('span[class="a-price-whole"]',0)->plaintext;
// echo "</span><br><br>";

// echo $html->find('span[class="a-size-medium a-color-base a-text-normal"]',1)->plaintext;
// echo "<span class='float-right'>";
// echo $html->find('span[class="a-price-symbol"]',1)->plaintext;
// echo $html->find('span[class="a-price-whole"]',1)->plaintext;
// echo "</span><br><br>";

// echo $html->find('span[class="a-size-medium a-color-base a-text-normal"]',2)->plaintext;
// echo "<span class='float-right'>";
// echo $html->find('span[class="a-price-symbol"]',2)->plaintext;
// echo $html->find('span[class="a-price-whole"]',2)->plaintext;
// echo "</span><br><br>";

// a-size-base-plus a-color-base a-text-normal

//1
if(isset($html->find('span[class="a-size-medium a-color-base a-text-normal"]',0)->plaintext)){
  // $url = $html->find('span[class="a-size-medium a-color-base a-text-normal"]',0)->plaintext;
  // echo "<a href=$url target='_blank'>echo $html->find('span[class="a-size-medium a-color-base a-text-normal"]',0)->plaintext)";</a>
  
  
  // $product1 = $html->find('span[class="a-size-medium a-color-base a-text-normal"]',0)->plaintext;
  // $link1 = $amz_str1.$product1.$amz_str2;
  // echo "<a href='$link1' target='_blank'>echo $product1</a>"; 


  echo $html->find('span[class="a-size-medium a-color-base a-text-normal"]',0)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('span[class="a-price-symbol"]',0)->plaintext;
  echo $html->find('span[class="a-price-whole"]',0)->plaintext;
  echo"</span><br><br>";


  echo $html->find('span[class="a-size-medium a-color-base a-text-normal"]',1)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('span[class="a-price-symbol"]',1)->plaintext;
  echo $html->find('span[class="a-price-whole"]',1)->plaintext;
  echo"</span><br><br>";

  
  echo $html->find('span[class="a-size-medium a-color-base a-text-normal"]',2)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('span[class="a-price-symbol"]',2)->plaintext;
  echo $html->find('span[class="a-price-whole"]',2)->plaintext;
  echo"</span><br><br>";

}

else{

//if(isset($html->find('span[class="a-size-base-plus a-color-base a-text-normal"]',0)->plaintext)){
  echo $html->find('span[class="a-size-base-plus a-color-base a-text-normal"]',0)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('span[class="a-price-symbol"]',0)->plaintext;
  echo $html->find('span[class="a-price-whole"]',0)->plaintext;
  echo "</span><br><br>";


  echo $html->find('span[class="a-size-base-plus a-color-base a-text-normal"]',1)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('span[class="a-price-symbol"]',1)->plaintext;
  echo $html->find('span[class="a-price-whole"]',1)->plaintext;
  echo "</span><br><br>";


  echo $html->find('span[class="a-size-base-plus a-color-base a-text-normal"]',2)->plaintext;
  echo "<span class='float-right'>";
  echo $html->find('span[class="a-price-symbol"]',2)->plaintext;
  echo $html->find('span[class="a-price-whole"]',2)->plaintext;
  echo "</span><br><br>";

}

?>
			
			</p>
            <hr>
           <button type="button" class="btn btn-deep-orange"><a href="<?php echo $amz_query;?>" id="visitsite" target='_blank'>Visit amazon</a></button>
          </div>
          <!--Card content-->

        </div>
        <!--Card-->

        <!--Card-->
        
        <!--Card-->

      </div>
      <!--Card group-->

    </div>
    <!--Grid column-->

  </div>
  <!--Grid row-->

</section>
<!--Section: Group of personal cards-->


<!-- Footer -->
<footer class="page-footer font-small  pt-4 btn-dark" id="footer">

  <!-- Footer Links -->
  <div class="container-fluid text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Content -->
        <h5 class="text-uppercase">Price Comparison Tool</h5>
        <p>Here you can compare prices of a product on various e-commerce platforms.</p>
        <p>This website is built by Group no. 110</p>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none pb-3">

      <!-- Grid column -->
      <div class="col-md-3 mb-md-0 mb-3">

        <!-- Links -->
        <h5 class="text-uppercase">E-commerce sites</h5>

        <ul class="list-unstyled">
          <li>
            <a href="#!">Amazon</a>
          </li>
          <li>
            <a href="#!">Flipkart</a>
          </li>
         
        </ul>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-3 mb-md-0 mb-3">

        <!-- Links -->
        <h5 class="text-uppercase">Links</h5>

        <ul class="list-unstyled">
          <li>
            <a href="https://www.amazon.com" target='_blank'>amazon.com</a>
          </li>
          <li>
            <a href="https://www.flipkart.com" target='_blank'>flipkart.com</a>
          </li>
          
        </ul>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

</footer>
<!-- Footer -->

<script type="text/javascript" src="js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript"></script>